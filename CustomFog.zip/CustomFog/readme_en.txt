Backslash (\): Toggle mod

1. Modify the map where you want to enable mod fog
In scene.ini, modify the map where you want to enable the mod fog. 0 is disabled (using the original fog in the game), 1 is enabled


2. Modify the fog color
Modify the fog color of each map in set_color.ini
To do this, first obtain a RGB color value(You can choose the color here: https://g.co/kgs/G38hiYU), For example 176, 155, 234. Then divide it by 255 to convert the range to between 0 and 1 before using

Example:
R: 176/255 ≈ 0.690196078
G: 155/255 ≈ 0.607843137
B: 234/255 ≈ 0.917647058

[CommandListCustomFogColor]
if $\SceneID\id == 301
	; 0. 賽前 | Pre-Match
	x160 = 0.690196078
	y160 = 0.607843137
	z160 = 0.917647058
else if $\SceneID\id == 401
	; 1. 軍工廠 | Arms Factory
	x160 = 0.123456789
	y160 = 0.123456789
	z160 = 0.123456789
...
endif
