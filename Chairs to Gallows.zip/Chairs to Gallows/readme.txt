請原諒我的稀爛英語，大部分都是機翻的，所以語氣可能怪怪的
Please forgive my poor English. Most of it is computer-translated, so the tone may be weird.

本模組僅供學術研究、個人使用與學習之目的，使用本模組可能導致帳號被封禁或其他遊戲內懲罰。任何因此產生的損失由使用者自行承擔，作者概不負責。
This mod is provided solely for academic research, personal use, and learning purposes. Using this mod may result in account bans or other in-game penalties. Any losses or consequences arising from its use are the sole responsibility of the user. The author assumes no liability.

據我所知第五人格在國際服熱度並不是很高(嗎？)，所以我在bilibili發布影片同時告訴他們我使用的工具想讓更多人知道模組(我不知道會不會因為這個影片導致官方封禁模組，要是真被封了別罵我😭)
As far as I know, Identity V is not very popular in international servers (is it?), so I posted a video on bilibili and told them about the tools I use to let more people know about the module (I don’t know if it’s because of this) The video caused the official to ban the module. If it is really banned, don’t scold me😭)
