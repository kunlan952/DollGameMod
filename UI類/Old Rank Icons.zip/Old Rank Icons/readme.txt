"等號(=)"：開關模組
"ctrl + ="：切換六階及以上圖標風格

"Equal sign(=)": toggle mod
"ctrl + =": toggle icon styles for tier VI and above
